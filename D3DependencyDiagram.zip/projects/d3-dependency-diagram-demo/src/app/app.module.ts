import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { D3DependencyDiagramConfigurationPresets } from '@hiwe-dev/datavis';
import { D3DependencyDiagramModule } from 'projects/d3-dependency-diagram/src/public-api';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    D3DependencyDiagramModule.forRoot({
      defaultConfiguration: D3DependencyDiagramConfigurationPresets[0].value
    })
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
