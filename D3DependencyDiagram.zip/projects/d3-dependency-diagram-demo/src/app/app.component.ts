import { Component } from '@angular/core';
import { ComponentLoadInfo } from '@hiwe-dev/datavis';
import { D3GraphTreeSampleData } from './sampledata-tree';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  data = D3GraphTreeSampleData;

  componentloaded(event: CustomEvent<ComponentLoadInfo>) {
    console.log('on componentloaded: %O', event.detail);
  }
}
