import { D3GraphData } from '@hiwe-dev/datavis';

export const D3GraphTreeSampleData: D3GraphData = {
  vertices: [
    {
      id: 'parentNode',
      dbId: 'parentNode',
      label: 'Parent',
    },
    {
      id: '1',
      dbId: '1',
      label: 'First level',
      percentage: 32,
    },
    {
      id: '2',
      dbId: '2',
      label: 'First level',
      value: 25,
    },
    {
      id: '3',
      dbId: '3',
      label: 'First level',
    },
    {
      id: '4',
      dbId: '4',
      label: 'Hiwe IT',
      image: 'https://i.ibb.co/DYmGWdp/hiwe-logo-tiger.png',
      percentage: 45,
      styleAttributes: {
        color: '#00A0E3',
      },
      attributes: {
        Address:
          'J. B. Jelačića 22C, 40000 Čakovec, Croatia, Office building: TICM 2',
        Email: 'info@hiwe-it.com',
        About_Us:
          'We provide industry software solutions. Our mission is to simplify production and increase quality.',
      },
    },
    {
      id: '5',
      dbId: '5',
      label: 'First level',
      icon: 'f0fc',
      value: 18,
      percentage: 44,
      styleAttributes: {
        labelColor: 'white',
      },
      group: '102',
    },
    {
      id: '6',
      dbId: '6',
      label: 'Second level',

      group: '102',
    },
    {
      id: '7',
      dbId: '7',
      label: 'Second level',
      icon: 'f818',
      styleAttributes: {
        labelColor: 'white',
      },
      group: '102',
    },
    {
      id: '8',
      dbId: '8',
      label: 'Second level',

      group: '102',
    },
    {
      id: '9',
      dbId: '9',
      label: 'Second level',
      percentage: 64,
      group: '102',
    },
    {
      id: '10',
      dbId: '10',
      label: 'Second level',
      percentage: 88,
      group: '102',
    },
    {
      id: '11',
      dbId: '11',
      label: 'Second level',
      percentage: 59,
    },
    {
      id: '12',
      dbId: '12',
      label: 'Second level',
    },
    {
      id: '13',
      dbId: '13',
      label: 'Tigergraph',
      value: 20,
      percentage: 85,
      icon: 'f1c0',
      image:
        'https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,f_auto,q_auto:eco/vootpjtmcyx0gt79zl6r',
      styleAttributes: {
        color: '#ff6d00',
        labelColor: '#ff6d00',
      },
      attributes: {
        Description: 'The Only Scalable Graph Database for the Enterprise',
        HQ: '3 Twin Dolphin Drive, Ste 225 Redwood City, CA 94605',
        Email: 'info@tigergraph.com',
      },
    },
    {
      id: '14',
      dbId: '14',
      label: 'Second level',
    },
    {
      id: '15',
      dbId: '15',
      label: 'Second level',
    },
    {
      id: '16',
      dbId: '16',
      label: 'Third level',
    },
    {
      id: '17',
      dbId: '17',
      label: 'Third level',
    },
    {
      id: '18',
      dbId: '18',
      label: 'Third level',
      styleAttributes: {
        color: '#880000',
        labelColor: 'white',
      },
      icon: 'f071',
      group: '101',
      attributes: {
        word: 'quick',
      },
    },
    {
      id: '19',
      dbId: '19',
      label: 'Third level',
      icon: 'f071',
      styleAttributes: {
        color: '#880000',
        labelColor: 'white',
      },
      attributes: {
        word: 'brown',
      },
      group: '101',
    },
    {
      id: '20',
      dbId: '20',
      image:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Vue.js_Logo_2.svg/1184px-Vue.js_Logo_2.svg.png',
      attributes: {
        version: 'Vue ver. 3.0.11',
      },
      percentage: 45,
      value: 3,
      styleAttributes: {
        color: '#b3e5cf',
      },
      label: 'Vue.js',
    },
    {
      id: '21',
      dbId: '21',
      label: 'Third level',
      attributes: {
        word: 'jumps',
      },
      value: 50,
    },
    {
      id: '22',
      dbId: '22',
      label: 'Third level',
      attributes: {
        word: 'over',
      },
      value: 53,
    },
    {
      id: '23',
      dbId: '23',
      label: 'Third level',
      attributes: {
        word: 'the',
      },
      value: 54,
    },
    {
      id: '24',
      dbId: '24',
      label: 'Third level',
      attributes: {
        word: 'lazy',
      },
      value: 80,
    },
    {
      id: '25',
      dbId: '25',
      label: 'Third level',
      attributes: {
        word: 'fox',
      },
      value: 41,
    },
    {
      id: '26',
      dbId: '26',
      icon: 'f7d8',
      label: 'Third level',
      styleAttributes: {
        labelColor: 'white',
      },
      group: '100',
      percentage: 55,
    },
    {
      id: '27',
      dbId: '27',
      label: 'Third level',
      icon: 'f587',
      styleAttributes: {
        labelColor: 'white',
      },
      group: '100',
    },
    {
      id: '28',
      dbId: '28',
      label: 'Fourth level',

      group: '104',
      value: 31,
    },
    {
      id: '29',
      dbId: '29',
      label: 'Fourth level',

      group: '104',
      value: 55,
    },
    {
      id: '30',
      dbId: '30',
      label: 'Fourth level',

      group: '104',
      value: 75,
    },
    {
      id: '31',
      dbId: '31',
      label: 'Fourth level',
      icon: 'f560',
      styleAttributes: {
        color: '#00AA00',
        labelColor: 'white',
      },
      group: '103',
    },
    {
      id: '32',
      dbId: '32',
      label: 'Fourth level',
      icon: 'f560',
      styleAttributes: {
        color: '#00AA00',
        labelColor: 'white',
      },
      group: '103',
    },
    {
      id: '33',
      dbId: '33',
      label: 'Fourth level',
      icon: 'f560',
      styleAttributes: {
        color: '#00AA00',
        labelColor: 'white',
      },
      group: '103',
    },
    {
      id: '34',
      dbId: '34',
      label: 'Fifth level',
      percentage: 38,
    },
    {
      id: '35',
      dbId: '35',
      label: 'Fifth level',
    },
    {
      id: '36',
      dbId: '36',
      label: 'Quasar',
      image: 'https://v0-17.quasar-framework.org/images/quasar-logo-big.png',
      percentage: 65,
      value: 2,
      styleAttributes: {
        color: 'white',
        labelColor: '#1976d2',
      },
      attributes: {
        version: '2.0.0-beta.14',
      },
    },
    {
      id: '37',
      dbId: '37',
      label: 'Fifth level',
      percentage: 29,
    },
    {
      id: '38',
      dbId: '38',
      label: 'Fifth level',
      percentage: 19,
    },
    {
      id: '39',
      dbId: '39',
      label: 'Fifth level',
    },
    {
      id: '40',
      dbId: '40',
      label: 'Custom radius with animation',
      percentage: 100,
      value: 4,
      radius: 150,
      styleAttributes: {
        color: 'black',
      },
      image: 'https://i.ibb.co/zVB4pqH/70a552e8e955049c8587b2d7606cd6a6.gif',
    },
    {
      id: '41',
      dbId: '41',
      label: 'Negative',
      percentage: 23,
      radius: 150,
      group: '105',
      image: 'https://hiwe-it.com/tg/prod7.jpg',
      styleAttributes: {
        color: '#550000',
      },
    },
    {
      id: '42',
      dbId: '42',
      label: 'Justify end',
      percentage: 48,
      radius: 150,
      group: '105',
      image: 'https://hiwe-it.com/tg/prod8.jpg',
      styleAttributes: {
        labelColor: 'white',
      },
    },
    {
      id: '43',
      dbId: '43',
      label: 'Justify end',
      percentage: 12,
      radius: 150,
      group: '105',
      icon: 'f11e',
      styleAttributes: {
        labelColor: 'white',
      },
    },
    {
      id: '44',
      dbId: '44',
      label: 'Fifth level',
    },
    {
      id: '45',
      dbId: '45',
      label: 'Justify end',
      group: '105',
      percentage: 53,
    },
    {
      id: '46',
      dbId: '46',
      label: 'Automatic type coloring (1)',
      type: 'type_1',
    },
    {
      id: '47',
      dbId: '47',
      label: 'Automatic type coloring (1)',
      type: 'type_1',
    },
    {
      id: '48',
      dbId: '48',
      label: 'Automatic type coloring (2)',
      type: 'type_2',
    },
    {
      id: '49',
      dbId: '49',
      label: 'Automatic type coloring (2)',
      type: 'type_2',
    },
    {
      id: '50',
      dbId: '50',
      label: 'Justify end',
      group: '105',
      percentage: 87,
      image: 'https://hiwe-it.com/tg/prod1.jpg',
      radius: 150,
      icon: 'f071',
      styleAttributes: {
        color: '#770000',
        labelColor: '#770000',
      },
    },
    {
      id: '51',
      dbId: '51',
      label: 'Fifth level',
      percentage: 90,
    },
    {
      id: '52',
      dbId: '52',
      label: 'Justify end',
      group: '105',
      radius: 150,
      percentage: 42,
      value: 23,
      image: 'https://hiwe-it.com/tg/prod5.jpg',
      styleAttributes: {
        color: '#CCCCCC',
      },
    },
    {
      id: '53',
      dbId: '53',
      label: 'Fifth level',
    },
    {
      id: '54',
      dbId: '54',
      label: 'Fifth level',
    },
    {
      id: '55',
      dbId: '55',
      label: 'Positive',
      group: '105',
      percentage: 20,
      radius: 150,
      image: 'https://hiwe-it.com/tg/prod6.jpg',
      styleAttributes: {
        color: 'green',
      },
    },
    {
      id: '56',
      dbId: '56',
      label: 'Justify end',
      group: '105',
      percentage: 100,
    },
    {
      id: '57',
      dbId: '57',
      label: 'Justify end',
      group: '105',
      percentage: 7,
      radius: 150,
      image: 'https://hiwe-it.com/tg/prod2.jpg',
    },
    {
      id: '58',
      dbId: '58',
      label: 'In progress...',
      percentage: 59,
      image:
        'https://i.gifer.com/origin/20/2087ca9db678798d037ff9625ebd2843_w200.gif',
      styleAttributes: {
        color: '#e6effb',
      },
    },
    {
      id: '59',
      dbId: '59',
      label: 'Fifth level',
    },
    {
      id: '60',
      dbId: '60',
      label: 'Custom defined vertex radius',
      group: '105',
      radius: 150,
      icon: 'f058',
      styleAttributes: {
        labelColor: '#00BB00',
        color: '#00BB00',
      },
      image: 'https://hiwe-it.com/tg/prod4.jpg',
    },
  ],
  edges: [
    {
      source: 'parentNode',
      target: '1',
      directed: true,
      type: 'type_1',
    },
    {
      source: 'parentNode',
      target: '2',
      directed: true,
      type: 'type_1',
    },
    {
      source: 'parentNode',
      target: '3',
      directed: true,
      type: 'type_1',
    },
    {
      source: 'parentNode',
      target: '4',
      directed: true,
      type: 'type_2',
    },
    {
      source: 'parentNode',
      target: '5',
      directed: true,
      type: 'type_2',
    },
    {
      source: '5',
      target: '6',
      directed: true,
    },
    {
      source: '5',
      target: '7',
      label: 'needs',
      directed: true,
    },
    {
      source: '5',
      target: '8',
      directed: true,
    },
    {
      source: '5',
      target: '9',
      directed: true,
    },
    {
      source: '5',
      target: '10',
      directed: true,
    },
    {
      source: '4',
      target: '11',
      directed: true,
    },
    {
      source: '4',
      target: '12',
      directed: true,
    },
    {
      source: '4',
      target: '13',
      label: 'partners',
      directed: true,
    },
    {
      source: '4',
      target: '14',
      directed: true,
    },
    {
      source: '4',
      target: '15',
      directed: true,
    },
    {
      source: '13',
      target: '16',
      directed: true,
    },
    {
      source: '13',
      target: '17',
      directed: true,
    },
    {
      source: '13',
      target: '18',
      styleAttributes: {
        color: '#880000',
      },
      directed: true,
    },
    {
      source: '13',
      target: '19',
      styleAttributes: {
        color: '#880000',
      },
      directed: true,
    },
    {
      source: '13',
      target: '20',
      directed: true,
    },
    {
      source: '13',
      target: '21',
      directed: true,
    },
    {
      source: '13',
      target: '22',
      directed: true,
    },
    {
      source: '13',
      target: '23',
      directed: true,
    },
    {
      source: '13',
      target: '24',
      directed: true,
    },
    {
      source: '13',
      target: '25',
      directed: true,
    },
    {
      source: '7',
      target: '26',
      label: 'causes',
      directed: true,
    },
    {
      source: '7',
      target: '27',
      label: 'leads to',
      directed: true,
    },
    {
      source: '23',
      target: '28',
      directed: true,
    },
    {
      source: '23',
      target: '30',
      directed: true,
    },
    {
      source: '9',
      target: '31',
      directed: true,
    },
    {
      source: '10',
      target: '32',
      directed: true,
    },
    {
      source: '10',
      target: '33',
      directed: true,
    },
    {
      source: '26',
      target: '30',
      directed: true,
    },
    {
      source: '26',
      target: '29',
      directed: true,
    },
    {
      source: '16',
      target: '34',
      directed: true,
    },
    {
      source: '17',
      target: '35',
      directed: true,
    },
    {
      source: '18',
      target: '36',
      directed: true,
    },
    {
      source: '33',
      target: '37',
      directed: true,
    },
    {
      source: '32',
      target: '38',
      directed: true,
    },
    {
      source: '31',
      target: '39',
      directed: true,
    },
    {
      source: '39',
      target: '43',
      directed: true,
    },
    {
      source: '37',
      target: '38',
      directed: true,
    },
    {
      source: '28',
      target: '40',
      directed: true,
    },
    {
      source: '40',
      target: '41',
      directed: true,
      type: 'type_3',
    },
    {
      source: '40',
      target: '42',
      directed: true,
      type: 'type_3',
    },
    {
      source: '29',
      target: '39',
      directed: true,
    },
    {
      source: '38',
      target: '43',
      directed: true,
    },
    {
      source: '38',
      target: '44',
      directed: true,
    },
    {
      source: '38',
      target: '45',
      directed: true,
    },
    {
      source: '36',
      target: '46',
      directed: true,
    },
    {
      source: '36',
      target: '47',
      directed: true,
    },
    {
      source: '36',
      target: '48',
      directed: true,
    },
    {
      source: '36',
      target: '49',
      directed: true,
    },
    {
      source: '36',
      target: '50',
      directed: true,
    },
    {
      source: '20',
      target: '51',
      directed: true,
    },
    {
      source: '20',
      target: '52',
      directed: true,
    },
    {
      source: '20',
      target: '53',
      directed: true,
    },
    {
      source: '53',
      target: '54',
      directed: true,
    },
    {
      source: '54',
      target: '55',
      directed: true,
    },
    {
      source: '1',
      target: '11',
      directed: true,
    },
    {
      source: '2',
      target: '11',
      directed: true,
    },
    {
      source: '3',
      target: '11',
      directed: true,
    },
    {
      source: '44',
      target: '56',
      directed: true,
    },
    {
      source: '51',
      target: '57',
      directed: true,
    },
    {
      source: '46',
      target: '58',
      directed: true,
    },
    {
      source: '47',
      target: '58',
      directed: true,
    },
    {
      source: '48',
      target: '58',
      directed: true,
    },
    {
      source: '49',
      target: '59',
      directed: true,
    },
    {
      source: '58',
      target: '60',
      directed: true,
    },
    {
      source: '59',
      target: '60',
      directed: true,
    },

    /*
    {
      source: '10',
      target: '45',
      directed: true,
    },
    */
  ],
  groups: [
    {
      id: '100',
      label: 'Third level group',
    },
    {
      id: '101',

      styleAttributes: {
        color: '#BB0000',
      },
    },
    {
      id: '102',
      label: 'Neutral',

      styleAttributes: {
        color: '#6cbeee',
      },
    },
    {
      id: '103',
      styleAttributes: {
        color: '#00BB00',
      },
    },
    {
      id: '104',
      styleAttributes: {
        color: '#f2c037',
      },
    },
    {
      id: '105',
      label: 'The end',
      hideGroup: true,
      styleAttributes: {
        color: '#00CC00',
      },
    },
  ],
};
