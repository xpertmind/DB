export class EventListenerManager {
  eventNames: any[];

  constructor(
    private targetElement: any,
    private targetObject: any,
    private prefix: string = 'e_'
  ) {
    this.eventNames = this.getEventNames();
  }

  subscribe() {
    this.eventNames.forEach((eventName) => {
      this.targetElement.addEventListener(eventName, this.getEvent(eventName));
    });
  }

  unsubscribe() {
    this.eventNames.forEach((eventName) => {
      this.targetElement.removeEventListener(
        eventName,
        this.getEvent(eventName)
      );
    });
  }

  private getEventNames() {
    const targetEventNames = getMethods(this.targetObject)
      .filter((methodName) => methodName.startsWith(this.prefix))
      .map((methodName) => methodName.replace(this.prefix, ''));

    return targetEventNames;
  }

  private getEvent(eventName: string) {
    return this.targetObject[`${this.prefix}${eventName}`];
  }
}

export function getMethods(obj: any): any[] {
  let properties = new Set();
  let currentObj = obj;
  do {
    Object.getOwnPropertyNames(currentObj).map((item) => properties.add(item));
  } while ((currentObj = Object.getPrototypeOf(currentObj)));
  return [...properties.keys()].filter(
    (item: any) => typeof obj[item] === 'function'
  );
}
