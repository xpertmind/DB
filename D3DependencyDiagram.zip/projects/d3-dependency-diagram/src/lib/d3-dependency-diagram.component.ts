import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {
  ComponentLoadInfo,
  D3DependencyDiagram,
  D3DependencyDiagramConfiguration,
  D3GraphData,
  Edge,
  Group,
  Vertex,
} from '@hiwe-dev/datavis';
import { D3DependencyDiagramDefaultSettings } from './d3-dependency-diagram.settings';
import { EventListenerManager } from './d3-event-listener.manager';

function createInitialGraphData(): D3GraphData {
  return {
    edges: [],
    vertices: [],
  };
}

@Component({
  selector: 'd3-dependency-diagram',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    style: 'width: 100%; height: 100%;',
  },
  template: ``,
})
export class D3DependencyDiagramComponent implements OnInit, OnDestroy {
  eventListenerManager: EventListenerManager;
  resizeObserver: ResizeObserver;

  diagramElement: any;
  diagram: D3DependencyDiagram;

  @Input()
  set data(data: D3GraphData | null) {
    if (!data) {
      return;
    }

    this.diagram.updateData(data);
  }

  @Input()
  set configuration(configuration: D3DependencyDiagramConfiguration | null) {
    if (!configuration) {
      return;
    }

    this.diagram.updateConfig(configuration);
  }

  @Output() componentloaded = new EventEmitter<
    CustomEvent<ComponentLoadInfo>
  >();
  @Output() showvertexinfo = new EventEmitter<CustomEvent<Vertex>>();
  @Output() hidevertexinfo = new EventEmitter<CustomEvent<Vertex>>();
  @Output() showedgeinfo = new EventEmitter<CustomEvent<Edge>>();
  @Output() hideedgeinfo = new EventEmitter<CustomEvent<Edge>>();
  @Output() showgroupinfo = new EventEmitter<CustomEvent<Group>>();
  @Output() hidegroupinfo = new EventEmitter<CustomEvent<Group>>();
  @Output() onisolation = new EventEmitter<
    CustomEvent<{ vertices: string[]; edges: Edge[] }>
  >();
  @Output() ondeisolation = new EventEmitter();

  constructor(
    @Inject(D3DependencyDiagramDefaultSettings)
    private defaultConfiguration: D3DependencyDiagramConfiguration,
    elementRef: ElementRef
  ) {
    this.diagramElement = elementRef.nativeElement;

    this.eventListenerManager = new EventListenerManager(
      this.diagramElement,
      this
    );

    this.diagram = new D3DependencyDiagram(
      this.diagramElement,
      this.defaultConfiguration,
      createInitialGraphData()
    );

    this.resizeObserver = new ResizeObserver(() => {
      this.diagram.onResize();
      this.diagram.zoomToFit();
    });
  }

  ngOnInit() {
    this.eventListenerManager.subscribe();
    this.resizeObserver.observe(this.diagramElement);
  }

  ngOnDestroy() {
    this.eventListenerManager.unsubscribe();
    this.resizeObserver.unobserve(this.diagramElement);
  }

  //Events
  e_componentloaded = (e: CustomEvent<ComponentLoadInfo>) => {
    this.componentloaded.emit(e);
  };

  e_showvertexinfo = (e: CustomEvent<Vertex>) => {
    this.showvertexinfo.emit(e);
  };

  e_hidevertexinfo = (e: CustomEvent<Vertex>) => {
    this.hidevertexinfo.emit(e);
  };

  e_showedgeinfo = (e: CustomEvent<Edge>) => {
    this.showedgeinfo.emit(e);
  };

  e_hideedgeinfo = (e: CustomEvent<Edge>) => {
    this.hideedgeinfo.emit(e);
  };

  e_showgroupinfo = (e: CustomEvent<Group>) => {
    this.showgroupinfo.emit(e);
  };

  e_hidegroupinfo = (e: CustomEvent<Group>) => {
    this.hidegroupinfo.emit(e);
  };

  e_onisolation = (e: CustomEvent<{ vertices: string[]; edges: Edge[] }>) => {
    this.onisolation.emit(e);
  };

  e_ondeisolation = () => {
    this.ondeisolation.emit();
  };
}
