import { InjectionToken, ModuleWithProviders, NgModule } from '@angular/core';
import {
  D3DependencyDiagramConfiguration,
  D3DependencyDiagramConfigurationPresets,
} from '@hiwe-dev/datavis';
import { D3DependencyDiagramComponent } from './d3-dependency-diagram.component';
import { D3DependencyDiagramDefaultSettings } from './d3-dependency-diagram.settings';

@NgModule({
  declarations: [D3DependencyDiagramComponent],
  providers: [
    {
      provide: D3DependencyDiagramDefaultSettings,
      useValue: D3DependencyDiagramConfigurationPresets[0].value,
    },
  ],
  imports: [],
  exports: [D3DependencyDiagramComponent],
})
export class D3DependencyDiagramModule {
  static forRoot(configuration: {
    defaultConfiguration: D3DependencyDiagramConfiguration;
  }): ModuleWithProviders<D3DependencyDiagramModule> {
    return {
      ngModule: D3DependencyDiagramModule,
      providers: [
        {
          provide: D3DependencyDiagramDefaultSettings,
          useValue: configuration.defaultConfiguration,
        },
      ],
    };
  }
}
