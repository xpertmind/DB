import { InjectionToken } from '@angular/core';
import { D3DependencyDiagramConfiguration } from '@hiwe-dev/datavis';

export const D3DependencyDiagramDefaultSettings =
  new InjectionToken<D3DependencyDiagramConfiguration>(
    'd3-dependency-diagram-default-settings'
  );
