export * from './lib/d3-dependency-diagram.component';
export * from './lib/d3-dependency-diagram.module';
